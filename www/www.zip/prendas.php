<?php
$temp=16;
if($temp>13)
{
echo "<img src='img/images.png' width='350' height='520' style=' border-radius:20px aling:center '>";
}
?>
