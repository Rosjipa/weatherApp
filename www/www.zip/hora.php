<?php
date_default_timezone_set("America/Bogota");
$fecha=date("Y/m/d");
$hora=date("H:i:s ");
$anio=date("Y");
$mes=date("m");
$dia=date("d");
echo $fecha."  ".$hora;
?>